// import { ADD_EMPLOYEE_REQUEST, ADD_EMPLOYEE_SUCCESS, ADD_EMPLOYEE_FAIL } from '../constants/employeeConstants';

// export const employeeAddReducer = (state = {}, action) => {
//   switch (action.type) {
//     case ADD_EMPLOYEE_REQUEST:
//       return { loading: true };
//     case ADD_EMPLOYEE_SUCCESS:
//       return { loading: false, success: true, employeeInfo: action.payload };
//     case ADD_EMPLOYEE_FAIL:
//       return { loading: false, error: action.payload };
//     default:
//       return state;
//   }
// };
