export const environment = {
    PRODUCTION: false,
    APIURL: "http://localhost:8000/api/v1/",
  };
  