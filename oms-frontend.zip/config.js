// ✅ GOOD - Only one export for API
export const API = 'http://localhost:8000/';
