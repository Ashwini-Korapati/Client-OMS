import React from 'react'

const Qpforms = () => {
  return (
    <div>Qpforms</div>
  )
}

export default Qpforms