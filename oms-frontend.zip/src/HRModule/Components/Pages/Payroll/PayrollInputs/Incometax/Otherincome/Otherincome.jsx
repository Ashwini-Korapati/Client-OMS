import React from 'react'
import './Otherincome.css'
 
function Otherincome() {
  return (
    <div>
         <div className="table-container1">
        <table className="tax-table1">
          <thead>
            <tr>
              <th>Description</th>
              <th>Max-Limit</th>
              <th>Amount</th>
              <th>Remark</th>
             
            </tr>
          </thead>
          <tbody>
            <tr>
              <td></td>
              <td>00.00</td>
              <td>00.00</td>
              <td></td>
            </tr>
            </tbody>
          </table>
          </div>
    </div>
  );
};
 
export default Otherincome;